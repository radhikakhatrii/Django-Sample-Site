from django.shortcuts import render
#from newsweb.models import Question
from account.models import Account
from django.shortcuts import render, redirect
from .forms import NewsForm
from .models import News
from django.urls import reverse_lazy
from django.views.generic.edit import CreateView


from django.utils import timezone

from django.db.models import Q


# Create your views here.
def homepage(request):
    context = {}
    accounts = Account.objects.all()
    category = request.GET.get('category', '')
    date=request.GET.get('date')
    news = News.objects.all().order_by('-created_at')
    if category:
        news = news.filter(category=category)
    if date:
        news= news.filter(date=date)
    return render(request, 'newsweb/home.html', {'news': news, 'category': category, 'date': date})



def submit_news(request):
    if request.method == 'POST':
        form = NewsForm(request.POST)
        if form.is_valid():
            news = form.save(commit=True)
            news.author = request.user
            news.save()
            return redirect('home')
    else:
        form = NewsForm()
    return render(request, 'submit_news.html', {'form': form})



from django.db.models.functions import Lower

def news_list(request,category=None):
    category = request.GET.get('category')

    if category:
        # convert category to lowercase
        category = category.lower()
        news = News.objects.filter(category=category)
    else:
        news = News.objects.all()

    context = {
        'news': news,
        'category': category,
    }

    return render(request, 'newsweb/home.html', context)












# from django.views.generic import ListView


# class NewsListView(ListView):
#     model = News
#     template_name = 'news_list.html'

#     def get_queryset(self):
#         category = self.request.GET.get('category', '')
#         if category:
#             queryset = News.objects.filter(category=category)
#         else:
#             queryset = News.objects.all()
#         return queryset










from django.shortcuts import render, get_object_or_404

def news_detail(request, pk):
    news = get_object_or_404(News, pk=pk)
    return render(request, 'news_detail.html', {'news': news})
