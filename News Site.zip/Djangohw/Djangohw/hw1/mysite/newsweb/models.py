from django.db import models
from django.utils import timezone


# PRIORITY = [
#     ('h', 'high'),
#     ('m', 'medium'),
#     ('l', 'low')
# ]
# # Create your models here.
# class Question(models.Model):
#     title           = models.CharField(max_length=60)
#     questions        = models.TextField(max_length=400)
#     priority        = models.CharField(max_length=1, choices= PRIORITY)

#     def __str__(self):
#         return self.title
#     class Meta:
#         verbose_name = "The Question"
#         verbose_name_plural = "People Questions"


# class News(models.Model):
#     title = models.CharField(max_length=200)
#     text = models.TextField()
#     category = models.CharField(max_length=50)
#     created_at = models.DateTimeField(auto_now_add=True)

#     def __str__(self):
#         return self.title
class News(models.Model):
    title = models.CharField(max_length=200)
    text = models.TextField()
    category = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']  # This line ensures that the latest news is displayed first

    def __str__(self):
        return self.title
# class News(models.Model):
#     title = models.CharField(max_length=200)
#     text = models.TextField()
#     category = models.CharField(max_length=50)
#     created_at = models.DateTimeField(auto_now_add=True)
#     date = models.DateField() # add this field

#     class Meta:
#         ordering = ['-created_at']  # This line ensures that the latest news is displayed first

#     def __str__(self):
#         return self.title


